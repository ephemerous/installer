//
// phone worker.js
//
// 2021.10.12 (from cf)
// 
// // upg: upload example-phone worker.. use from browser.
//
// * OK -- check status (cors)
// * CORS PROXY -- with api-key
// * PUT/POST/(DELETE) -- with api-key .. store things in kv
// * GET -- get things from kv
// * MUSTACHE -- convert {{param}} values.
//
// upg: support DELETE (and move?) of static
//
// upg: rebuild this
//		- fix cors to run next first.
//		- make fields in line (some might be on the requester side)
//		


// ----------------------------------------
const strip = (req,pre)=>{
  //  or?

  // strip '/api' pre from url /api/fetch
  //
  // api(strip(request,'/api'))
  //
  const {url,body} = req

  const xurl = new URL(url)

  const reg = new RegExp(`^${pre}`)
  xurl.pathname = xurl.pathname.replace(reg,'')

  const u = xurl.toString()

  const r = new Request(u,req) // ok?
  return r
  }

// -----------------------------------------
// upg: cors = new Cors({settings}) or? // is there express for cf workers?
const cors = (req,next)=>{ // or?
// next: cors should call next first then self.  (if not options?)
	next = next || ((req,res)=>res)

	const {method,headers} = req

	let res = false

	const origin = headers.get('origin')

	if(method === 'OPTIONS'){
		const a = headers.get('Access-Control-Request-Headers')

		const h = {
            		'Access-Control-Allow-Methods': '*',//"GET,HEAD,POST,OPTIONS",
            		'Access-Control-Max-Age': '86400'
			}
        
        	if(a)
	            h['Access-Control-Allow-Headers'] = a
	
		if(origin)
			h['Access-Control-Allow-Origin'] = origin

		res = new Response(null, {headers:h})

		}//if
	else {
		const headers = {
			}
		if(origin)
			headers['Access-Control-Allow-Origin'] = origin

		headers['Access-Control-Expose-Headers'] = '*'
		headers['Vary'] = 'Origin'

		const r = new Response(null,{headers})

		res = next(req,r)
		}

	return res
	}//


// ----------------------------------------
const ok = req=>{

	console.log('ok...')
	const next = (req,res)=>{
		return new Response('ok!',res)
		}

	const c = cors(req,next)

	return c
	}

// -----------------------------------------
const api = req=>{
	let res = false

	const {url} = req
	const {pathname} = new URL(url)

	console.log('api pathname',pathname)

	res = res || new Response('404',{status:404})

	return res
	}

// -----------------------------------------
const fetchProxy = req=>{

	const next = async (req,res)=>{

		//let res = false

		const {apiKey} = JSON.parse(await NAMESPACE.get('params')) || {}
		
		const {url,headers,method,body} = req

		const tryApiKey = headers.get('x-api-key')
		const reqUrl = headers.get('x-proxy-request-url')

		console.log('api',{apiKey,tryApiKey})


		if(tryApiKey && apiKey && (apiKey == tryApiKey) && reqUrl){
		
			const r = new Request(null,req) // duplicate request (as can't modify immutable)

			// --------------
			const map = ['x-api-key','x-proxy-request-url'] // remove these
			for(const p of r.headers){
				const [t,v] = p
				const tt = t.toLowerCase()

				if(
					tt.startsWith('cf-') ||
					//tt.startsWith('sec-fetch-') || // or?  // or control with header params
					map.includes(tt)
				) {
					r.headers.delete(t)
					}
				}

			// --------------
			const opts = {
				method: r.method,
				headers: r.headers
				}

			if(body)
				opts.body = await req.arrayBuffer() //or?

			const f = await fetch(reqUrl,opts) // or?

			const rr = new Response(f.body,{headers: f.headers})			

			for(const p of res.headers){
				const [t,v] = p
				rr.headers.set(t,v)  // or?
				}

			res = rr
			}
		else
			res = new Response(null,{status:403})

		res = res || new Response('404',{status:404})

		return res
		}//func next

	//next(req,new Response())
	return cors(req,next)
	}


// ----------------------------------------
const mustache = async req=>{
	// upg: cors?
	
	const {method,url,headers,cf,body} = req
	const {pathname,searchParams} = new URL(url)
	const _pathname = pathname == '/'?'/index.html':pathname
	const kvPath = `/static${_pathname}` // upg: pull basename '/static' from kv params
	
	res = false

	console.log({kvPath})
	const {value,metadata} = await NAMESPACE.getWithMetadata(kvPath,{type:'text'})

	console.log({value,metadata})

	if(value) {
		console.log('mustache',{kvPath,value})
		let r = value
		for(const p of searchParams){
			const [t,v] = p
			const s = new RegExp('{{'+t+'}}','g') // upg: regescape?
			r = r.replace(s,v)
			console.log(t,v,s)
			}//for

		const {contentType} = metadata || {}
		const _contentType = (metadata||{'Content-Type':'application/xml'})['Content-Type'] || contentType // fix this.
		res = new Response(r,{headers:{'Content-Type':_contentType}})		
		}//if

	return res || new Response('FS 404',{status: 404})
	}//func

// ----------------------------------------
const fileServer = async req=>{
	const {method,url,headers,cf,body} = req
	const {pathname} = new URL(url)

	const _pathname = pathname == '/'?'/index.html':pathname


	const kvPath = `/static${_pathname}` // upg: pull basename '/static' from kv params
	
	let res = false

	// upg: way to get metadata? OPTIONS? or?
	const next = async (req,res)=>{
		if(method == 'PUT' || method=='POST' || method=='DELETE'){
			// put uses form data
			// post uses content-type and direct data
			const {apiKey} = JSON.parse(await NAMESPACE.get('params')) || {}
			const tryApiKey = headers.get('x-api-key')

			if(tryApiKey && apiKey && (tryApiKey == apiKey)){ // upg: checkKey(tryApiKey) or?
			
				const key = kvPath

				let metadata = {}
				let value = ''

				if(method == 'DELETE'){
					//upg: check meta data for system level/permissions
					//const d = await NAMESPACE.list({prefix:key})
					//console.log('d',d)
					const r = await NAMESPACE.delete(key)
					//console.log('deleted',r,key)
					//no complaint if key does not exist.
				}
				else
				{
					if(method == 'PUT'){
						const d = await req.formData()
						value = d.get('value') // upg: how/why make this binary?
						metadata = JSON.parse(d.get('metadata')) // or
						}
					else {  //POST
						const contentType = req.headers.get('content-type') || 'application/octet-stream'
						metadata = {'Content-Type': contentType}
						//upg: include meta data vrom x-metadata = 'name=value' etc. params
						value = body//await req.arrayBuffer() // can we keep this a stream?
						}
					
					console.log('store',{key,value,metadata})

					const p = await NAMESPACE.put(key, value, {metadata})  //, expirationTtl}) // 14 days or 1 year durable // upg: ,control (like ttl)
					console.log({p})
				}

				const rr = new Response(JSON.stringify(true),{headers:{'Content-Type': 'application/json'}})
				for(const p of res.headers){
					const [t,v] = p
					rr.headers.set(t,v)  // or?
					}

				res = rr // cors should be after or?
				}//if
			}//if
		else {
			//upg: permission files? .. metadata so need apiKey to read and/or?
			const {value,metadata} = await NAMESPACE.getWithMetadata(kvPath,{type:'stream'})
			console.log({value,metadata})
			if(value){
				const {contentType} = metadata || {}
				const _contentType = (metadata||{'Content-Type':'application/xml'})['Content-Type'] || contentType // fix this.
				res = new Response(value,{headers:{'Content-Type':_contentType}})
				}
			}
		

		return res || new Response('FS 404',{status: 404})

		}//func: next

	return cors(req,next)
	}//func: fileServer

// -----------------------------------------
const onfetch = e=>{
	const {request} = e

	const {method,url,headers,cf} = request
	const {pathname} = new URL(url)

	let res = false

	if(pathname.startsWith('/ok'))
		res = ok(request)
	else
	if(pathname.startsWith('/_mustache')) // or /api/mustache
		res = mustache(strip(request,'/_mustache'))
	else
	if(pathname.startsWith('/api/'))
		res = api(strip(request,'/api'))
	else
	if(pathname.startsWith('/fetch-proxy'))
		res = fetchProxy(request)
	else
		res = fileServer(request)

	res = res || new Response('404',{status: 404})

	e.respondWith(res)

	}//func




// -------------------------------------
addEventListener("fetch", onfetch)

