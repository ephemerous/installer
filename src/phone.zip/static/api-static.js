//
// 2021.10.27
//

// ==============================================================
class Static {
	// static file storage (public internet accessable)
	
	// ----------------------------
	constructor(opts){
		opts = opts || {}
		const {api} = opts
		this.api = api
		}

	// ----------------------------
	async delete(path){
		//upg: opts for security/opts/access or?

		const {api} = this
		const {install} = api //or?
		const {service} = install
		const {apiKey,apiUrl} = service

		const u = `${apiUrl}${path}`

		const f = await fetch(u,{
			method: 'DELETE',
			headers:{
				'x-api-key': apiKey
				}
			})

		return f.ok
		}

	// ----------------------------
	async update(path,body,opts){
		opts = opts || {}
		const {api} = this
		const {install} = api //or?
		const {service} = install
		const {apiKey,apiUrl} = service

		const s = `${apiUrl}${path}`


		const headers = {
			'x-api-key': apiKey
			}

		if(opts.contentType)
			headers['Content-Type'] = opts.contentType


		//console.log('...',s,'POST',body,opts,{api:this.api})


		const f = await fetch(s,{ // cors is built in
			method:'POST',
			headers,
			body
			})

		if(f.ok){
			const r = await f.json()
			console.log({r})
			}
		else {
			console.log('fail')
			}


		const url = s

		return {url}
		}

	}//class


export default Static
