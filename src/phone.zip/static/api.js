import TwilioHelper from './libs/lib-twilio-helper.js'

import Static from './api-static.js'
import Telcom from './api-telcom.js'


import {define,emit} from './libs/lib-little-element-toolkit.js'

//
// next:
// 	- add static
// 	- 
//
// start with handle .. then can add call object with methods(, events?) eventually.
//
// upg: focus on  api mthen ui/
//
//	- on('dial')?
//	- on('incoming')?
//
// 	- on('connection') // this could be from our dial or incoming
// 	- on('accepted')
// 	- on('disconnection')
//
//

//
// DIAL
// 	- on ringing: accept event
//
// 	- on hang up: disconnect event
//
//
// INCOMING
// 	- on ringing:
//
//
// CALL
// 	- accept() .. only on incoming call. (optional rtcConfig, rtcConstants for the call)
// 	- reject() .. only on incoming call - hangup will be issued to calling party
// 	- ignore() .. only on incoming call - no longer will ring sound here (could pickup on another line)
// 	
// 	- disconnect() .. drop call.
//
// 	(note a non accepted call won't generate a discconect event?)
//


///////////////////////////////////////////////////////////////////////
class API extends EventTarget {

	// ----------------
	constructor(opts){
		super()
		opts = opts || {}

		this.opts = opts

		this.install = {}

		this.ready = (async n=>{
			//console.log("ready")
			})()

		const fetchProxy = this.fetch.bind(this)
		this.fetchProxy = fetchProxy

		//this.service = new Service({api:this,fetchProxy})
		this.telcom = new Telcom({api:this})
		this.static = new Static({api:this})

		}

	// ---------------
	async fetch(url,options){
		const {service:{apiUrl,apiKey}} = await this.about()


		const fetchUrl = `${apiUrl}/fetch-proxy`

		const _opts = JSON.parse(JSON.stringify(options))
		_opts.headers = _opts.headers || {}
		_opts.headers['x-api-key'] = apiKey
		_opts.headers['x-proxy-request-url'] = url
		if(options.body)
			_opts.body = options.body
		
		return fetch(fetchUrl,_opts)
		}

	// ----------------
	async about(){
		return this.install
		}

	// ----------------
	async setInstall(c){
		const {fetchProxy} = this

		this.install = c
		console.log('api install set to',c)

		if(!this.twilio && c.twilio){
			console.log('API: add twilio')

			const {twilio} = c
			const {accountSid,apiSid,apiSecret} = twilio

			this.twilio = new TwilioHelper({fetchProxy,accountSid,apiSid,apiSecret})
			await this.telcom.addResource(this.twilio)
			}

		// upg: add basic services the same way?
		//
		}//func

	}//class

export default API








///////////////////////////////////////////////////////////////////////
/* class Service extends EventTarget {
	constructor(opts){
		super()

		opts = opts || {}
		const {api,fetchProxy} = opts

		this.api = api
		this.fetchProxy = fetchProxy
		}

	async update(i){
		}

	async add(i){
		}
	}//class
*/

