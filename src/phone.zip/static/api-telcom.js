
import {define,emit} from './libs/lib-little-element-toolkit.js'

class Telcom extends EventTarget {
	constructor(opts){
		super()

		opts = opts || {}
		const {api} = opts

		this.resources = []

		this.handleCount = 0
		this.handles = {}

		this.api = api

		this.devTwilioDevice = false
		}

	addHandle(opts){
		this.handleCount++
		const handle = this.handleCount
		opts.handle = handle

		//upg: opts.handle = handle
		this.handles[handle] = opts

		console.log('add handle',handle,this.handles)

		return handle
		}

	 deleteHandle(h){
		 console.log('delete handle',h,this.handles[h],this.handles)
		 delete this.handles[h]
	 	}

	// ---------------------
	_getCallInfo(n){
		const {handles} = this
		let h = handles[n]
		if(!h){
			const l = Object.keys(handles)
			if(l.length > 0){
				h = handles[l[0]]
				}
			}

		return h
		}

	// ---------------------
	async callDetail(n){
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			const s = call.status()

			const {direction,number} = h

			const r = {status: s,direction, number}

			return r
			}
		}

	// ---------------------
	async status(n){
		//pending/ringing
		//
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			return call.status()
			}
		}

	// ---------------------
	async toggleMute(n){
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			call.mute(!call.isMuted())
			}
		}

	// ---------------------
	async isMuted(n){
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			return call.isMuted()
			}

		return null
		}

	// ---------------------
	async keypress(key,n){
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			call.sendDigits(key)
			}
		}

	// ----------------------
	async ignore(n){
		// incoming (mute ring here)
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			console.log('telcom: ignore()',call)
			// does this not work? mute ourslefs (looks like can't pickup afterwards)
			call.ignore()

			emit(this,'disconnection',n) // or?
			}
		}

	// ----------------------
	async reject(n){
		// incoming (hang up)
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			console.log('telcom: reject()',call)
			call.reject()
			}
		}

	// ---------------------
	async accept(n){
		// incoming
		const h = this._getCallInfo(n)
		if(h){
			const {call} = h
			console.log('telcom: accept()',call)
			call.accept()
			}
		}

	 // ---------------------
	 async disconnect(n){
		 // drop connected call
		 console.log('dissconnect..',this.handles)
		 const h = this._getCallInfo(n)
		 if(h){
			const {call} = h
			console.log('telcom: disconnect()')
			call.disconnect()
		 	}
		 else
			 console.log('nothing to disconnect',handles,n)
	 	}

	 // ---------------------
	 async about(){
		 const {api} = this
		 const {twilio} = api
		 console.log(twilio)
		 const l = await twilio.numbers.list()

		 const numbers = l.map(v=>{
			 const {phone_number:number,sid:guid} = v
			 return {number,guid}
		 	})

		 return {numbers}
	 	}


	// -----------------------------------------
	_useCall(call,opts){
		// or?
		//
		//const {call} = this._getCallInfo(handle)
		opts = opts || {}

		const {number:__num} = opts
		
		const {parameters,direction:__dir} = call
		const {From,StirStatus} = parameters

		const direction = __dir.toLowerCase()
		const number = __num || From || 'no-number'

		const r = {type:'call',number,direction,call}

		const handle = this.addHandle(r)

		const c = call
		console.log('use call',c,handle)

		// ----------------------------
		const connect = n=>{
			emit(this,'connection',{handle})
			}

		const accepted = n=>{
			emit(this,'accepted',{handle})
			}
				
		const disconnect = n=>{
			emit(this,'disconnection',{handle})
			this.deleteHandle(handle)
			}
		// -----------------------------

		if(direction == 'incoming'){
			connect()
			}

		c.on('disconnect',e=>{
			console.log('telcom: disconnect !!! CLEAN UP CONNECTION')
			//emit(this,'disconnect',{handle})
			disconnect()
			})

		c.on('accept',e=>{
			// 
			// we dialed (instant accept)
			// or
			// we accepted (after call comes in and rings)
			//

			// on call start (ring cycle)
			console.log('telcom: accept')
			//emit(this,'accept',{handle})
			//emit(this,'dial',{handle})

			if(direction == 'outgoing')
				connect()
			else
				accepted()

			})

		c.on('error',e=>{
			console.log('telcom: error')
			//emit(this,'error',{handle})
			})

		
		c.on('mute',e=>{
			console.log('telcom: mute')

			emit(this,'mute',{handle})
			})

		c.on('warning',(name,data)=>{
			console.log('telcom: warning',name,data)

			//emit(this,'warning',{handle,name,data})
			})

		c.on('cancel',e=>{
			console.log('telcom: cancel')
			//
			// they canceled
			//
			//emit(this,'cancel',{handle})
			disconnect()
			})

		c.on('reject',e=>{
			console.log('telcom: reject')

			// we rejected
			//
			//emit(this,'reject',{handle})
			disconnect()
			})

		}//func
		

	// --------------------------------------
	async addResource(opts){
		const {Device} = Twilio // upg?

		const {resources,api} = this
		console.log('add resource',opts)

		console.log(this)
		const token = await (async n=>{
			const {twilio} = await api.about()
			console.log('token...',twilio)

			const {stationName,outgoingApplicationSid} = twilio

			const conf = {identity:stationName,outgoingApplicationSid} 
			return await api.twilio.tokens.create(conf)
			})()



		// --------------------
		const incoming = c=>{
			this._useCall(c)
			}


		// ---------------------
		//return
		// upg: don't specify codecs?
		const d = new Device(token)//,{debug:false,closeProtection:false,codecPreferences:['opus','pcmu']})

		d.on('error',e=>{console.log('error',e)})
		
		d.on('registered',e=>{console.log('registered')})
		d.on('registering',e=>{console.log('registering')})
		d.on('unregistered',e=>{console.log('unregistered',e)})

		d.on('incoming',incoming)

		d.register()

		const i = {twilio:opts,device:d}
		resources.push(i) // upg" or
		this.devTwilioDevice = d // temp upg: support multiple
		}

	// ---------------------
	async dial(opts){
		//upg: resource busy support.
		const {devTwilioDevice} = this
		let handle  = false
		if(devTwilioDevice){
			const number = opts
			console.log('dial',number)
			const d = devTwilioDevice
			const To = number

			console.log('telcom: dial/connect()')
			const c = await d.connect({params:{To}})

			this._useCall(c,{number})

			}
		else
			alert('no dial device')

		return handle
		}

	 // ------------------
	 test(){
		 emit(this,'incoming',{parameters:{From:'12345'}})
	 	}
	}//class

export default Telcom
