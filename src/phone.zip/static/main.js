//
// next: update installer (get.) .. use installer util.
//  		- test install.. including setup twilio.
// 
//
// upg: setup as page (get ready for that)
// 	... make github/cf accounts (use 5P)
// 		-- switch to using 5P generarlly.
// 		- make github project for ep-installer
// 			- static build command
// 			- use installer util to build .zip.
// 			or
//


import SetupNewInstall from './apps/setup-new-install/main.js'
import SetupTwilio from './apps/setup-twilio/main.js'
import Run from './apps/run/main.js'
import Activate from './apps/activate/main.js'

import PhoneKeypad from './libs/ui-phone-keypad.js'

import API from './api.js'

;(async n=>{

	let install = false

	const api = new API()

	const dB = document.querySelector('body')

	const switchTo = s=>{
		console.log('switch to',s)
		dB.innerHTML = ''
		dB.appendChild(s)
		}

	const updateInstall = async n=>{
		console.log('update install!',install)

		n = n || install
		install = n

		localStorage.setItem('install',JSON.stringify(n))
		await api.setInstall(n)
		const {activationKey} = n
		if(activationKey){
			//upg: delete old? or?
			await api.static.update('/'+activationKey,JSON.stringify(n))
			await api.static.delete('/install.json')
			}
		}//func

	// ----------------------------
	const goWelcome = async n=>{
		const d = document.createElement('div')
		d.textContent = 'Ahoy.'
		d.style.fontSize = 'min(15vw,55px)'
		d.style.fontWeight = 'bold'
		switchTo(d)
		}
	
	// -----------------------------
	const goActivationKey = n=>new Promise((res,rej)=>{
		console.log('create activation key')
		const s = new SetupNewInstall({api})

		s.addEventListener('done',async ({detail:{activationKey}})=>{
			install.activationKey = activationKey
			install.source = 'local'
			await updateInstall()

			//await api.static.delete('install.json')
			
			res(true)
			})

		switchTo(s)
		})

	// -----------------------------
	const goActivate = n=>new Promise((res,rej)=>{
		console.log('activate')
		const s = new Activate({api})

		s.addEventListener('done',async ({detail:data})=>{
			console.log('data',data)
			if(data){
				await updateInstall(data)
				}
			res(true)
			})

		switchTo(s)
		})
	// -----------------------------
	const goSetupTwilio = async n=>new Promise((res,rej)=>{
		const {fetchProxy} = api
		console.log('setup twilio')
		const s = new SetupTwilio({api,fetchProxy})

		s.addEventListener('done',async ({detail:twilio})=>{
			install.twilio = twilio // upg: check if exists or?
			await updateInstall()
			res(true)
			})

		switchTo(s)
		})

	// -----------------------------
	const goRun = async n=>new Promise((res,rej)=>{
		const s = new Run({api})
		switchTo(s)
		})


	// -----------------
	const install_p = (async n=>{
		let i = false
		try {
			i = JSON.parse(localStorage.getItem('install'))
			if(i)
				i.source = 'local'
			}
		catch(e){
			//console.log(e)
			}

		if(!i){
			try {
				const f = await fetch('./install.json')
				i = await f.json()
				if(i)
					i.source = 'install.json'
				}
			catch(e){
				console.log(e)
				}

			}

		return i
		})();



	// ----------------------------
	const goTest = async n=>{
		const d = document.createElement('div')
		//d.style.width = '300px'
		//d.style.height = '600px'
		//d.style.width = '33%'
		//d.style.margin = 'auto'
		d.style.height = '100%'

		
		dB.classList.remove('welcome')
		const s = new PhoneKeypad({api,fontSize: 1.25})
		s.addEventListener('press',e=>{
			const {detail:key} = e
			console.log('press:',key)
			})

		s.style.width = '100%'
		s.style.height = '100%'

		//s.style.backgroundColor = 'pink'
		d.appendChild(s)
		switchTo(d)
		}



	// -----------------
	const next = async ()=>{
		//
		// install.json on new phone software install
		// 	- moved to activation-activationkey.json when storeded locally in agent.
		// 
		// if no install.json and no locally stored data then
		// 	- assume new copy of device but existing activation info.
		//
		// (upg: option to not store online (keep local file))
		// (upg: option for lockbox)
		// (upg: option for password protect activation key file)
		//

		let goNext = false

		const n = install // or?

		console.log('next',n,api)

		if(n){
			const {twilio,source} = n
			if(source == 'install.json'){ // we're installing...
				await goActivationKey()
				goNext = true
				}
			else
			if(!twilio){ // haven't setup twilio yet
				console.log('need twilio')
				//upg: once have alt coms twilio will be an optional provision/marketplace resource.
				await goSetupTwilio()
				goNext = true
				}
			else {
				// we're all set.
				console.log('run phone')
				await goRun()
				}
			}
		else
			{ // must be installed (since no install.json file.. but not activated on this agent)
			console.log("need activation")
			await goActivate()
			goNext = true
			}

		// ----------------
		if(goNext)
			next() //or?
		else
			console.log('done.')

		}//func



	////////////////////////////////////////////////////////////////////
	//// ///////////////////////////////////////////////////////////////

	//goTest() ;return

	await goWelcome() // AHOY.


	install = await install_p  // local storage?, install.json?
	console.log('start via...',{install})
	
	// ------------------
	if(install){
		install.service = install.service || false
		install.twilio = install.twilio || false
		install.backblaze = install.backblaze || false
		//install.cloudflare = install.cloudflare || false
		//install.emailengine = install.emailengine || false
		//install.vultr = install.vultr || false
		//install.youtube = install.youtube || false
		//install.github = install.github || false
		//

		console.log('setting api install data',install)
		await api.setInstall(install) // convey install info to api
		}//if

	// --------------------
	setTimeout(async n=>{
		dB.innerHTML = ''
		dB.classList.remove('welcome')



	
		if(false){ // test
			console.log("TESTING!!! (skip regular steps.)")
			//console.log('s',await api.static.update('/test/abc','hi'))
	
			// upg: how can we search messages here?
			//console.log('s',await api.telcom.messages.list())
			}
		else
			next() // figure what to do next from state.

		},install?2/3*1000:2500)//500) // upg: 500 after seen ahoy once.


	})();
