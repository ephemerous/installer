//
// Setup -- initial phone software install.
//
// 2021.10.19
//
//
//
//

import randStr from '../../libs/lib-random-string.js'


const define = (name,Element)=>{
	const n = name+'-'+(randStr(6).toLowerCase())
	customElements.define(n,Element)
	}

const emit = (el,name,data)=>{
	const opts = {}
	if(data)
		opts.detail = data
	const e = new CustomEvent(name,opts)
	el.dispatchEvent(e)
	}


class Element extends HTMLElement {

	constructor(opts){
		super()

		opts = opts || {}
		
		const dom  = this.attachShadow({mode:'open'})
		this.dom = dom

		const activationKey = randStr().toLowerCase()

		const i = {activationKey}

		const S = `	
			<style>
				:host {
					display: grid;
					height: 100%;
					place-content: center;
					contain: content;
					padding: 25px;
					box-sizing: border-box;
					}

				.key {font-size: 150%;}

				.subtext {margin-top: 5px;}

				a {color: #fff; text-decoration: none; font-weight: bold; display: block; margin-top: 15px;}
			</style>
			<div class='key'>Activation Key: <b>${activationKey}</b></div>
			<div class='subtext'>Store this key in a secure location.</div>
			<a href='#continue-with-install'>Next</a>
			`

		//upg: add password to unlock activation key data.

		dom.innerHTML = S

		dom.querySelector('a').onclick = e=>{
			e.preventDefault()
			emit(this,'done',i)
			}

		

		}//func

	connectedCallback(){
		const e = new CustomEvent('connected')
		this.dispatchEvent(e)
		}

	adoptedCallback(){
		const e = new CustomEvent('adopted')
		this.dispatchEvent(e)
		}

	}//class
	
define('setup',Element)


export default Element


