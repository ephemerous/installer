//
// Activate -- reactivate (on a new device but existing host install)
//
// 2021.10.19
//
//
//

import randStr from '../../libs/lib-random-string.js'
import TwilioHelper from '../../libs/lib-twilio-helper.js'


const BASE_NAME = 'activate'


const define = (name,Element)=>{
	const n = name+'-'+(randStr(6).toLowerCase())
	customElements.define(n,Element)
	}

const emit = (el,name,data)=>{
	const opts = {}
	if(data)
		opts.detail = data
	const e = new CustomEvent(name,opts)
	el.dispatchEvent(e)
	}

///////////////////////////////////////////////////////////////////////
class Element extends HTMLElement {

	constructor(opts){
		super()

		opts = opts || {}
		
		const {api,fetchProxy} = opts

		this.fetchProxy = fetchProxy

		const dom  = this.attachShadow({mode:'open'})
		this.dom = dom

		let twilio = {}

		let twi = false

		const S = `	
			<style>
				:host {
					display: block;
					height: 100%;
					justify-content: center;
					contain: content;
					padding: 25px;
					box-sizing: border-box;
					}

				:host {font-size: 150%;}

				main {
					display: grid;
					xheight: 100%;
					justify-content: center;
					text-align: center;
					}

				input {background: #111; padding: 15px; text-align: center; font-size: 5vw; color:#eee; outline: none; border: none; margin: 5px; border-radius: 3px;}

				a {text-align: center; color: #fff; text-decoration: none; font-weight: bold; display: block; margin-top: 25px; margin-bottom: 25px;}

				.hidden {display: none;}
			</style>

			<main class='setup-twilio hidden'>
				<h1>Twilio</h1>
				<input name='accountSid' placeholder='Account SID' autofocus>
				<input name='apiSid' placeholder='API SID'>
				<input name='apiSecret' placeholder='API Secret'>

				<a class='twilio-settings-button' href='#continue-to-phone-select'>Next</a>
			</main>

			<main class='setup-number hidden'>
				<h1>Select Number</h1>
				<div class='content'></div>
			</main>
			
			<main class='provision hidden'>
				<h1>Provision</h1>
				<div class='content'></div>
			</main>
			`

		dom.innerHTML = S

		const show = n=>{
			if(n){
				console.log(n)
				Array.from(dom.querySelectorAll('main')).
					forEach(v=>v.classList.add('hidden'))

				dom.querySelector(n).classList.remove('hidden')
				}
			}//func


		// --------------------------------------------
		const doProvision = async twilio=>{
			const dM = dom.querySelector('.provision .content')
			dM.innerHTML = ''

			show('.provision')


			console.log('provision',twilio)
			const {phoneSid} = twilio
			const {installId} = await api.about()
			const stationName = installId
			const id = randStr() // so not to guess to read programming
			const basePath = id

			const a = await twi.numbers.about(phoneSid)
			const {voice_url,sms_url,phone_number,friendly_name} = a
			console.log({voice_url,sms_url,phone_number,a})

			const d = document.createElement('div')
			d.textContent = `Provisioning ${friendly_name}`

			dM.appendChild(d)

			const dialOut = 
			`<?xml version="1.0" encoding="UTF-8"?>
	<Response>
	<Say>Dialing...</Say>
	<Dial callerId='${phone_number}'>{{To}}</Dial>
	</Response>`

			const dialIn = 
	`<?xml version="1.0" encoding="UTF-8"?>
	<Response>
	<Dial>
	<Client>${stationName}</Client>
	</Dial>
	</Response>`
		
			const SmsIn = 
	`<?xml version="1.0" encoding="UTF-8"?>
	<Response></Response>`			

			console.log({dialOut},{dialIn},{SmsIn})

			const FriendlyName = `${stationName}` // upg: include install id etc.
			const out_VoiceUrl = `/${basePath}/twilio/dial-out.xml` // hack? _mustache translation.. or /api/static/mustache
			const in_VoiceUrl = `/${basePath}/twilio/dial-in.xml`
			const in_SmsUrl = `/${basePath}/twilio/sms-in.xml`

			console.log({FriendlyName,out_VoiceUrl,in_VoiceUrl,in_SmsUrl})

			// --- update files on host -------------------------------------
			// next: get this working
			const {fullOutVoiceUrl,fullInVoiceUrl,fullInSmsUrl} = await (async n=>{
				//return {fullOutVoiceUrl:'https://fulloutvoiceurljskfjoeiw.com',fullInVoiceUrl:'https://fullinvoiceurljfiwefoeiw.com',fullInSmsUrl:'https://fullinsmsurljfmeiwojf.com'}	
				const {url:fullOutVoiceUrl} = await api.static.update(
					out_VoiceUrl,
					dialOut,
					{contentType:'application/xml'})

				const {url:fullInVoiceUrl} = await api.static.update(
					in_VoiceUrl,
					dialIn,
					{contentType:'application/xml'})


				const {url:fullInSmsUrl} = await api.static.update(
					in_SmsUrl,
					SmsIn,
					{contentType:'application/xml'})

				const r = {fullOutVoiceUrl,fullInVoiceUrl,fullInSmsUrl}

				return r
				})();
			// -------------------------------------------------------------
			
		//	const _fullOutVoiceUrl = 'https://example.com'
			
			const ou = new URL(fullOutVoiceUrl)
			ou.pathname = '/_mustache'+ou.pathname
			const _fullOutVoiceUrl = ou.toString()

			const aO = await twi.applications.create({FriendlyName,VoiceUrl:_fullOutVoiceUrl,VoiceMethod:'GET'})

			const {sid:outgoingApplicationSid} = aO
			console.log({outgoingApplicationSid,_fullOutVoiceUrl},aO)


			let delay = 1000
			if(true){
				if(voice_url && sms_url ){
					const d = document.createElement('div')
					d.textContent = 'voice and sms urls exists for '+`${friendly_name}`+', manually configure.'
					dM.appendChild(d)
					delay += 4500
					}
				else {
					const o = {}
					
					if(!voice_url) {
						o.VoiceUrl = fullInVoiceUrl
						o.VoiceMethod= 'GET'
						}
					else {
						const d = document.createElement('div')
						d.textContent = 'voice url exists for '+`${friendly_name}`+', manually configure.'
						dM.appendChild(d)
						delay += 2500
						}

					if(!sms_url) {
						o.SmsUrl = fullInVoiceUrl
						o.SmsMethod= 'GET'
						}
					else {
						const d = document.createElement('div')
						d.textContent = 'sms url exists for '+`${friendly_name}`+', manually configure.'
						dM.appendChild(d)
						delay += 2500
						}


					console.log({o})
					const nO = await twi.numbers.update(phoneSid,o) //,SmsUrl:'https://example.com/sms.xml')
					console.log({nO})
					// code: 21402
					// message: "VoiceUrl is not a valid URL: /static/8fbc32vs5wQyd6Cy/twilio/dial-in.xml"
					// more_info: "https://www.twilio.com/docs/errors/21402"
					// status: 400

					// >> or full phone record on success.
					//

					}//else
				}//if



			//await api.updateInstall({type:'twilio',outgoingApplicationSid:'sid-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'})

			twilio.stationName = stationName
			twilio.outgoingApplicationSid = outgoingApplicationSid
			twilio.id = id
			twilio.phoneSid = phoneSid

			setTimeout(n=>next(),delay)

			}


		// --------------------------------------------
		const next = async n=>{
			console.log('next',JSON.parse(JSON.stringify(twilio)))
			const {phoneSid,outgoingApplicationSid} = twilio

			if(phoneSid && !outgoingApplicationSid){ // not yet setup calling params.
				console.log({phoneSid,outgoingApplicationSid})
				doProvision(twilio)
				}
			else
			if(phoneSid && outgoingApplicationSid){
				// we're ready
				console.log('done!') 
				//upg: provide detail for main to set cloud values.
				emit(this,'done',twilio)
				}//if
			}//func

		show('.setup-twilio')

	
		dom.querySelector('.twilio-settings-button').onclick = async e=>{
			e.preventDefault()
			const accountSid = dom.querySelector('[name=accountSid]').value.trim()
			const apiSid = dom.querySelector('[name=apiSid]').value.trim()
			const apiSecret = dom.querySelector('[name=apiSecret]').value.trim()

			twilio = {accountSid,apiSid,apiSecret}

			twi = new TwilioHelper({fetchProxy,accountSid,apiSid,apiSecret})
			const r = await twi.verifyCredentials()
			console.log('verify',r)

			if(r){
				console.log('continue with install..')  /// note: add ready to provisioned twilio? // or.. look for outgoing values etc to know if fully provisioned (and where to continue with install)
				show('.setup-number')
				//console.log(await twi.messages.list())
				
				const dM = dom.querySelector('.setup-number')

				const l = await twi.numbers.list()
				const len = l.length

				if(len > 0){

					l.forEach((v,i)=>{
						console.log(v)
						const {friendly_name,phone_number,sid,status} = v
						const a = document.createElement('a')
						a.textContent = friendly_name+((len > 1 &&  i == 0)?' -- this':'')
						a.href = '#use'
						a.onclick = async e=>{
							e.preventDefault()
							console.log('use',sid)
							if(sid){	
								//await api.updateInstall({type:'twiliox',phoneSid:sid})
								twilio.phoneSid = sid
								next()
								}
							else
								console.log('no sid?')
							}
						dM.appendChild(a)
						})

					const d = document.createElement('div')
					d.textContent = 'tap number to continue'
					dM.appendChild(d)
					}
				else
					{
					const d = document.createElement('div')
					d.textContent = 'No phone numbers?'
					dM.appendChild(d)
					}
				}
			else
				alert('check values')

			console.log({r})
			//emit(this,'done',i)
			}//func


		if(true){ //debugging
			const url = new URL(location.href)
			const id = url.searchParams.get('id')
			const a = url.searchParams.get('a')
			const k = url.searchParams.get('k')
			console.log({id,a,k})

			dom.querySelector('[name=accountSid]').value = id
			dom.querySelector('[name=apiSid]').value = a
			dom.querySelector('[name=apiSecret]').value = k
			}

		

		}//func

	}//class
	
define(BASE_NAME,Element)

export default Element

