//
// Run -- run phone
//
// 2021.10.26
//
//
// upg: on end of call give call stats (who, start time,day, length) ? .. when new or press clear display goes away.
//
// next: provisioning
//


import {define,emit} from '../../libs/lib-little-element-toolkit.js'
import PhoneKeypad from '../../libs/ui-phone-keypad.js'

const BASE_NAME = 'run'

// -------------------------------------------
const canPlay = async n=>{
	//
	// 2021.11.26
	//
	// https://developer.mozilla.org/en-US/docs/Web/Media/Autoplay_guide
	// https://gist.github.com/novwhisky/8a1a0168b94f3b6abfaa
	const m = 'data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA/+M4wAAAAAAAAAAAAEluZm8AAAAPAAAAAwAAAbAAqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV////////////////////////////////////////////AAAAAExhdmM1OC4xMwAAAAAAAAAAAAAAACQDkAAAAAAAAAGw9wrNaQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/+MYxAAAAANIAAAAAExBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV/+MYxDsAAANIAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV/+MYxHYAAANIAAAAAFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'

	const p = document.createElement('audio')
	p.src = m

	let result = false
	try {
		const r = await p.play()
		result = true
		}
	catch(e){
		const {name} = e
		if(name == 'NotAllowedError'){
			// reason is not yet allowed.
			}
		}

	// upg: long result option tells why?

	return result
	}


///////////////////////////////////////////////////////////////////////
class Element extends HTMLElement {

	constructor(opts){
		super()

		opts = opts || {}
		
		const {api} = opts


		const dom  = this.attachShadow({mode:'open'})
		this.dom = dom


		const S = `	
			<style>
				:host {
					height: 100%;
					contain: content;
					box-sizing: border-box;
					overflow-y: scroll;
					}


				.content {
					height: 100%;
					display: grid;
					grid-template-rows: auto 1fr;
					}

				.audio-paused {padding: 15px; text-align: center;}
				.audio-paused span {font-size: 85%;}

				.mode {height: 100%;}
				.page {height: 100%;}


				/**********************************/
				.waiting.mode {
					display: grid;
					justify-items: center;
					align-items: end;
					}

				.waiting.mode .dial.button {padding: 15px; font-size: 125%;}


				/**********************************/
				.dialing.mode {
					}
				
				.dialing.mode .info {font-size: 48px; height: 1.2em; padding: 15px 5px 15px 5px; text-align: center; overflow: hidden; font-weight: bold;}

				.dialing.mode .keypad.mode {
					display: grid;
					grid-template-rows: auto 1fr auto;
					}

				.dialing.mode .keypad.mode .options {
					display: grid;
					grid-template-columns: repeat(3,1fr);
					place-items: center;
					margin: 15px;
					}


				/**********************************/
				.in-call.mode .main.page{
					display: grid;
					grid-template-rows: 1fr auto;
					}
				
				.in-call.mode .info {font-size: 48px; text-align: center; overflow: hidden; font-weight: bold; place-self: center;}

				.in-call.mode .options {
					display: grid;
					grid-template-columns: repeat(3,1fr);
					place-items: center;
					margin: 15px;
					}


				.incoming-call {
					text-align: center;
					}
				.incoming-call .info {
					font-size: 36px;
					font-weight: bold;
					overflow: hidden;
					margin: 15px;
					}
				.incoming-call .options {
					display: grid;
					grid-template-columns: repeat(2,1fr);
					}

				.incoming-call .options > * {padding: 12px;}


				.content.muted .in-call.mode .mute.button {background: yellow; color: #111;}


				.content.can-play .audio-paused {display: none;}

				.content:not(.waiting-mode) .waiting.mode {display: none;}
				.content:not(.dialing-mode) .dialing.mode {display: none;}
				.content:not(.in-call-mode) .in-call.mode {display: none;}
				.content:not(.pending) .incoming-call {display: none;}


				.hidden {display: none;}


				.go-item {color: #43f508;}
				.stop-item {color: #ff4700;}

				.options {font-size: 150%; font-weight: bold;}
				
				a {text-decoration: none; color: yellow;}


				@media (min-width: 1024px) {
					.content {width: 1024px; margin: auto;}
					}
			</style>

			<div class='content'>
				<div class='extras'>
					<div class='audio-paused'>audio paused <span>(tap to unpause)</span></div>
					<div class='incoming-call'>
						<div class='info'>number</div>
						<div class='options'>
							<a class='answer button go-item' href='#answer'>Answer</a>
							<a class='cancel button stop-item' href='#cancel'>Cancel</a>
						</div>
					</div>
				</div>

				<div class='modes'>
					<div class='waiting mode'>
						<div class='dial button'>tap to dial</div>
					</div>

					<div class='dialing mode'>
						<div class='list mode hidden'></div>
						<div class='keypad mode'>
							<div class='info'>number</div>
							<div class='keypad'></div>
							<div class='options'>
								<a class='cancel button stop-item' href='#cancel'>cancel</a>
								<a class='send button go-item' href='#send'>send</a>
								<a class='clear button' href='#clear'>clear</a>

							</div>
						</div>
					</div>

					<div class='in-call mode'>
						<div class='main page'>
							<div class='info'></div>
							<div class='options'>
								<a href='#keypad' class='keypad button'>123</a>
								<a href='#disconnect' class='disconnect button stop-item'>disconnect</a>
								<a href='#mute' class='mute button'>mute</a>
							</div>
						</div>
						<div class='keypad page'></div>
					</div>
				</div>
				
				
			</div>
			`

		dom.innerHTML = S


		const dC = dom.querySelector('.content')
		const dO = dom.querySelector('.dialing.mode .keypad.mode .info')
		const dI = dom.querySelector('.in-call.mode .info')


		const dial = async n=>{
			//n = '15555555555'
			const c = await api.telcom.dial(n)
			//console.log('s',await api.telcom.messages.list())
			}


		;(//dial keypad
		n=>{
			const d = dom.querySelector('.dialing.mode .keypad.mode .keypad')
			const s = new PhoneKeypad()

			const o = dO

			dom.querySelector('.dialing.mode .keypad.mode .send.button').addEventListener('click',e=>{
				console.log('send')
				const v = o.textContent
				dial(v)
				})

			dom.querySelector('.dialing.mode .keypad.mode .cancel.button').addEventListener('click',e=>{
				mode = '' //  waiting is default mode
			})

			dom.querySelector('.dialing.mode .keypad.mode .clear.button').addEventListener('click',e=>{
				const v = o.textContent
				o.textContent = v.substr(0,v.length-1)
				})
			
			s.addEventListener('press',({detail:key})=>{
				o.textContent +=  key
				})

			d.appendChild(s)
		})();

		dom.querySelector('.mute.button').addEventListener('click',async e=>{
			await api.telcom.toggleMute()
			})

		dom.querySelector('.in-call.mode .disconnect.button').addEventListener('click',async e=>{
			await api.telcom.disconnect()
			})

		dom.querySelector('.in-call.mode .keypad.button').addEventListener('click',async e=>{
			window.scrollTo({left:0,top:9999,behavior:'smooth'})
			})



		dom.querySelector('.incoming-call .answer.button').addEventListener('click',async e=>{
			await api.telcom.accept()
			})

		dom.querySelector('.incoming-call .cancel.button').addEventListener('click',async e=>{
			await api.telcom.reject()
			})

		


		;(//dfmf keypad
		n=>{
			const d = dom.querySelector('.in-call.mode .keypad.page')
			const s = new PhoneKeypad()

			s.addEventListener('press',({detail:key})=>{
				api.telcom.keypress(key)
				})

			d.appendChild(s)
		})();


		// -------------------------------------------------------
		let mode = '' // waiting is default
		const updateDisplay = async n=>{
			// n = debug test?
			// how to check if audio paused?
			const  playWorks = await canPlay()
			dC.className = 'content' // clear content classes

			const {classList} = dC

			let m = mode

			const c = n || //{number:'+123123123123',direction:'outgoing'}
					//{number:'12312312312',direction:'incoming',status:'pending'}
				   await api.telcom.callDetail()
			console.log({c})
			if(c){
				const {direction,number,status:s} = c
				if(direction == 'outgoing'){
					console.log({s})
					m = 'in-call'
					}
				else {
					//incoming
					dom.querySelector('.incoming-call .info').textContent = number // or?

					if(s == 'pending'){
						classList.add('pending')
						}
					else
					if(s == 'open'){
						m = 'in-call'
						}

					}//else

				//if(m == 'in-call') // or?
				dI.textContent = number //or?

				}//if



			if(playWorks)
				classList.add('can-play')

			let muteText = 'mute'
			if(await api.telcom.isMuted()){
				classList.add('muted')
				muteText = 'muted'
				}

			dom.querySelector('.in-call.mode .mute.button').textContent = muteText


			classList.add((m || 'waiting')+'-mode')
			}


/*		const connection = async n=>{
			//
			// dial out (send)
			// or
			// incoming-call
			//
			const handle = n

			//const {number,direction} = 
				//{number:'+123123123123',direction:'outgoing'}
			//	await api.telcom.callDetail() || {}

			//if(direction == 'outgoing')
			//	mode = '' // detect in-call states
				
				updateDisplay()
			}
*/

		// -----------------------------
		this.ready = (async n=>{
			await updateDisplay()
			//updateDisplay({number:'1234',direction:'outgoing'}) // test
			})()


		let _userMediaCheck = false
		dC.addEventListener('click',async e=>{

			if(!_userMediaCheck){
				//or
				_userMediaCheck = true
				try {
					const m = await navigator.mediaDevices.getUserMedia({audio:true})
					console.log('m',m)
					}	
				catch(e){
					// NotAllowedError or NotFoundError
					//
					// upg: present message based on state
					// upg: how to check if changed?
					// permissions api?
					//
					_userMediaCheck = name
					const {name,code,message} = e
					console.log('no media',{code,name,message})
					}
				}

			// for tap to unpause audio
			//or?
			updateDisplay()
			})

		dom.querySelector('.waiting.mode').addEventListener('click',e=>{
			mode = 'dialing'
			dO.textContent = ''//''
			})



		// -------------------------------------------------------
		api.telcom.addEventListener('connection',e=>{
				console.log("..connection")
				//const {detail:handle} = e
				//connection(handle)
				updateDisplay()
				})

		// ----------
		api.telcom.addEventListener('accepted',e=>{
				console.log("..accepted")
				//const {detail:handle} = e
				updateDisplay()
				})

		// ----------
		api.telcom.addEventListener('disconnection',e=>{
			console.log("..disconnection")
			//const {detail:handle} = e
			//detectMode()
			//mode = '' // waiting is default
			updateDisplay()
			})

		// ----------
		api.telcom.addEventListener('mute',async e=>{
			//const {detail:handle} = e
			updateDisplay()
			})

		}//func

	}//class
	
define(BASE_NAME,Element)

export default Element

