//
// Activate -- reactivate (on a new device but existing host install)
//
// 2021.10.19
//
//
//

import {define,emit} from '../../libs/lib-little-element-toolkit.js'


const BASE_NAME = 'activate'


///////////////////////////////////////////////////////////////////////
class Element extends HTMLElement {

	constructor(opts){
		super()

		opts = opts || {}
		
		const {api} = opts

		const dom  = this.attachShadow({mode:'open'})
		this.dom = dom

		const S = `	
			<style>
				:host {
					display: grid;
					height: 100%;
					place-content: center;
					contain: content;
					padding: 25px;
					box-sizing: border-box;
					}

				:host {font-size: 150%;}

				input {background: #111; padding: 15px; text-align: center; font-size: 5vw; color:#eee; outline: none; border: none;}

				a {text-align: center; color: #fff; text-decoration: none; font-weight: bold; display: block; margin-top: 25px; margin-bottom: 25px;}
			</style>
			<main>
				<input placeholder='activation key' autofocus>
				<a href='#activate-device'>Activate</a>
			</main>
			`

		dom.innerHTML = S

		//upg: debounce
		dom.querySelector('a').onclick = async e=>{
			e.preventDefault()
			const v = dom.querySelector('input')
			const n = `${v.value.trim()}`//.json`
			try {
				const f = await fetch(n)
				const r = await f.json()
				//api.updateInstall(r)
				//alert('Activated!')
				emit(this,'done',r)
				}
			catch(e){
				console.log({e})
				alert('check code.')
				}
			}//func

		

		}//func

	}//class
	
define(BASE_NAME,Element)

export default Element

